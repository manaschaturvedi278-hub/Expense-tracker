# Expense Tracker
Offline-first Android prototype for Kotlin + Jetpack Compose.

Open this folder in Android Studio (Ladybug or newer), let Gradle sync, then Run on an Android device/emulator.

Features in this V1 prototype:
- ₹500 starting virtual wallet
- Per-transaction, daily and monthly hard caps
- Blocking dialog before balance changes
- Categories and transaction history
- Basic monthly analytics
- Rules screen

For production: replace in-memory state with Room, use Room @Transaction for atomic wallet+expense writes, add proper date boundaries, tests, backup, and encrypted storage as needed.
