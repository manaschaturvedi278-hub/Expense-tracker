package com.expensetracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.NumberFormat
import java.util.Locale

data class Expense(val amount: Long, val category: String, val note: String)
data class Rules(val perTransaction: Long = 250, val daily: Long = 300, val monthly: Long = 5000)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ExpenseTrackerApp() }
    }
}

@Composable
fun ExpenseTrackerApp() {
    var balance by remember { mutableLongStateOf(50000) } // paise
    var rules by remember { mutableStateOf(Rules()) }
    var expenses by remember { mutableStateOf(listOf<Expense>()) }
    var screen by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Expense Tracker") }) },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(screen == 0, { screen = 0 }, label={Text("Home")}, icon={})
                    NavigationBarItem(screen == 1, { screen = 1 }, label={Text("Analytics")}, icon={})
                    NavigationBarItem(screen == 2, { screen = 2 }, label={Text("Rules")}, icon={})
                }
            },
            floatingActionButton = {
                if (screen == 0) FloatingActionButton({ showAdd = true }) { Text("+") }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when(screen) {
                    0 -> Home(balance, expenses)
                    1 -> Analytics(expenses, balance)
                    2 -> RulesScreen(rules) { rules = it }
                }
                if (showAdd) AddExpenseDialog(
                    onDismiss = { showAdd = false },
                    onAdd = { amount, cat, note ->
                        val today = expenses.sumOf { it.amount }
                        val month = today
                        val blocked = when {
                            amount <= 0 -> "Enter a valid amount."
                            amount > balance -> "Transaction Blocked: Insufficient wallet balance."
                            amount > rules.perTransaction * 100 -> "Transaction Blocked: Amount exceeds your preset limit of ₹${rules.perTransaction}."
                            today + amount > rules.daily * 100 -> "Transaction Blocked: Daily spending cap of ₹${rules.daily} would be exceeded."
                            month + amount > rules.monthly * 100 -> "Transaction Blocked: Monthly spending cap of ₹${rules.monthly} would be exceeded."
                            else -> null
                        }
                        if (blocked != null) error = blocked
                        else { balance -= amount; expenses = expenses + Expense(amount,cat,note); showAdd=false }
                    }
                )
                error?.let { msg ->
                    AlertDialog(onDismissRequest={error=null}, confirmButton={Button({error=null}){Text("OK")}},
                        title={Text("Transaction Blocked")}, text={Text(msg)})
                }
            }
        }
    }
}

fun money(paise: Long): String = NumberFormat.getCurrencyInstance(Locale("en","IN")).format(paise / 100.0)

@Composable fun Home(balance: Long, expenses: List<Expense>) {
    LazyColumn(Modifier.padding(20.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item { Text("My Wallet", style=MaterialTheme.typography.titleMedium); Text(money(balance), style=MaterialTheme.typography.displaySmall) }
        item { Text("Recent Transactions", style=MaterialTheme.typography.titleLarge) }
        if (expenses.isEmpty()) item { Text("No expenses yet. Tap + to add one.") }
        items(expenses.reversed()) { e -> Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp), Arrangement.SpaceBetween) { Text("${e.category}
${e.note}"); Text("-${money(e.amount)}") } } }
    }
}

@Composable fun Analytics(expenses: List<Expense>, balance: Long) {
    val total = expenses.sumOf { it.amount }
    LazyColumn(Modifier.padding(20.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { Text("Monthly Analytics", style=MaterialTheme.typography.headlineMedium) }
        item { Text("Total spent: ${money(total)}") }
        item { Text("Wallet remaining: ${money(balance)}") }
        item { Text("Category breakdown", style=MaterialTheme.typography.titleLarge) }
        items(expenses.groupBy{it.category}.entries.toList()) { (cat,list) ->
            val sum=list.sumOf{it.amount}; val pct=if(total==0L)0 else sum*100/total
            Text("$cat — ${money(sum)} ($pct%)")
            LinearProgressIndicator({ if(total==0L)0f else sum.toFloat()/total.toFloat() }, Modifier.fillMaxWidth())
        }
    }
}

@Composable fun RulesScreen(r: Rules, onSave:(Rules)->Unit) {
    var p by remember(r){mutableStateOf(r.perTransaction.toString())}; var d by remember(r){mutableStateOf(r.daily.toString())}; var m by remember(r){mutableStateOf(r.monthly.toString())}
    Column(Modifier.padding(20.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("Spending Rules", style=MaterialTheme.typography.headlineMedium)
        OutlinedTextField(p,{p=it},label={Text("Max per transaction (₹)")})
        OutlinedTextField(d,{d=it},label={Text("Daily cap (₹)")})
        OutlinedTextField(m,{m=it},label={Text("Monthly cap (₹)")})
        Button({onSave(Rules(p.toLongOrNull()?:250,d.toLongOrNull()?:300,m.toLongOrNull()?:5000))}){Text("Save Rules")}
    }
}

@Composable fun AddExpenseDialog(onDismiss:()->Unit,onAdd:(Long,String,String)->Unit) {
    var amount by remember{mutableStateOf("")}; var cat by remember{mutableStateOf("Food")}; var note by remember{mutableStateOf("")}
    val cats=listOf("Food","Commute","Books & Study","Snacks","Bills","Misc")
    AlertDialog(onDismissRequest=onDismiss, title={Text("Add Expense")},
        text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("Amount (₹)")})
            OutlinedTextField(cat,{cat=it},label={Text("Category")})
            OutlinedTextField(note,{note=it},label={Text("Note")})
            Text("Categories: ${cats.joinToString(", ")}")
        }},
        confirmButton={Button({onAdd((amount.toLongOrNull()?:0)*100,cat,note)}){Text("ADD EXPENSE")}},
        dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}
